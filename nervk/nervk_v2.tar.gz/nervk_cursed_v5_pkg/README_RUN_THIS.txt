NERVK CURSED DESCENT v5
=======================

Run prebuilt:
  ./RUN_ME.sh
  # or directly:
  chmod +x ./nervk
  ./nervk

Rebuild:
  ./REBUILD_ME.sh
  # or: sh ./build_goblin.sh

Controls:
  WASD          move
  Mouse         look
  LMB           fire
  Mouse wheel   change weapon
  1/2/3         pistol / shotgun / rocket
  M             toggle automap
  TAB           hold automap
  ESC           quit

What changed in v5:
- Added an automap bound to M / TAB.
- Map shows floor layout, exit, pickups, enemies, and player position.
- BLACKOUT floors hide small enemy blips so the map itself becomes a bit cursed.
- Enemy/floor roles are sharper:
  - BLACKOUT leans into spitters and corridor denial.
  - SWARM biases harder toward skitters.
  - FAMINE swaps more ranged threats into bruiser/melee pressure.
  - HUNT adds another weaker tall teleporting bastard.
- Shotgun now shoves enemies back, making it a proper panic tool.
- Bruisers charge harder when they have line of sight.
- Starting ammo and between-floor rewards are tighter.

Important:
- .patch files are diffs. Do not run them with bash.
- To apply a patch manually: patch -p0 < nervk_cursed_v5.patch
- The build script defaults to bundled tiny SDL/GL compat headers because
  distro headers can produce a larger binary.
- To force system headers: USE_SYSTEM_HEADERS=1 ./build_goblin.sh
- The build script autotunes xz settings and keeps the smallest stream.

Expected result varies slightly by GCC/binutils/xz version, but should be
around 28 KB and only list libc.so.6 under DT_NEEDED.
