#!/bin/sh
set -eu
cd "$(dirname "$0")"
chmod +x ./nervk
exec ./nervk "$@"
