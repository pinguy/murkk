.nervk cursed v9 — seed UI / copy / retry-floor
================================================

Run:
  chmod +x ./nervk
  ./nervk

or:
  ./RUN_ME.sh

Rebuild:
  ./REBUILD_ME.sh

Controls:
  WASD       move
  Mouse      look
  LMB        fire / start / restart run
  1/2/3      pistol / shotgun / rocket
  Mousewheel cycle weapons
  M          toggle automap
  TAB        hold automap
  ESC        quit

Title seed controls:
  E          edit seed
  0-9 A-F    type hex seed, up to 8 digits
  BACKSPACE  delete seed digit
  ENTER      apply seed
  CLICK      start descent

Death screen:
  C          copy replay command to clipboard
  R          retry the current floor from its starting state
  CLICK      restart the whole run from floor 1

What changed in v9:
  - title screen seed entry without needing command-line flags
  - death screen can copy ./nervk --seed 0xXXXXXXXX to clipboard
  - death screen can retry the current floor using the saved floor-start seed/resources
  - stays under 32 KiB on the dev build

Still in from v8:
  - boss breach floors reserve enemy slots before normal room spawning
  - boss floors reliably spawn fat brute + 4 spitters
  - automap no longer covers the STALKED / PERK / SPEED-RAGE status stack

Still in from v7:
  - permadeath death readout: final depth + original seed printed to terminal
  - death screen shows depth, seed, and in-process best depth
  - perk tier every 5 floors: extra supplies between descents + curse resistance
  - boss breach floor every 6 floors
  - rare temporary SPEED and RAGE pickups
  - stalker/Nemesis pressure after the late-game threshold and on boss floors
  - no asset files; SDL/GL/libm are loaded at runtime; DT_NEEDED is libc only

Seed sharing still works from shell:
  ./nervk --seed 12345

On death, terminal output looks like:
  [nervk] died depth=17 seed=00C0FFEE best=17

Tiny build notes:
  build_goblin.sh uses the bundled compat headers by default and autotunes xz.
  Set USE_SYSTEM_HEADERS=1 if you want distro SDL2/GL headers instead.

Verification included:
  build_v9.log              - local rebuild output
  smoke_v9.log              - smoke-test output
  boss_spawn_sweep_v8.log   - inherited floor-18 seeded boss reservation sweep
