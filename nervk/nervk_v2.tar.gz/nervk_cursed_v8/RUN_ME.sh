#!/bin/sh
DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
chmod +x "$DIR/nervk"
exec "$DIR/nervk" "$@"
