.nervk cursed v8 — boss floor/hud fix
======================================

Run:
  chmod +x ./nervk
  ./nervk

or:
  ./RUN_ME.sh

Rebuild:
  ./REBUILD_ME.sh

Controls:
  WASD       move
  Mouse      look
  LMB        fire / start / restart
  1/2/3      pistol / shotgun / rocket
  Mousewheel cycle weapons
  M          toggle automap
  TAB        hold automap
  ESC        quit

What changed in v8:
  - boss breach floors now reserve enemy slots before normal room spawning
  - boss floors skip the kind-coverage top-up that could fill MAXENEMY first
  - boss block now reliably gets to spawn its fat brute + 4 spitters
  - automap no longer covers the STALKED / PERK / SPEED-RAGE status stack
  - no feature bloat; this is a correctness/tuning pass over v7

Still in from v7:
  - permadeath death readout: final depth + original seed printed to terminal
  - death screen shows depth, seed, and in-process best depth
  - perk tier every 5 floors: extra supplies between descents + curse resistance
  - boss breach floor every 6 floors
  - rare temporary SPEED and RAGE pickups
  - stalker/Nemesis pressure after the late-game threshold and on boss floors
  - no asset files; SDL/GL/libm are loaded at runtime; DT_NEEDED is libc only

Seed sharing:
  ./nervk --seed 12345

On death, terminal output looks like:
  [nervk] died depth=17 seed=00C0FFEE best=17

Tiny build notes:
  build_goblin.sh uses the bundled compat headers by default and autotunes xz.
  Set USE_SYSTEM_HEADERS=1 if you want distro SDL2/GL headers instead.

Verification included:
  build_v8.log              - local rebuild output
  smoke_v8.log              - smoke-test output
  boss_spawn_sweep_v8.log   - floor-18 seeded boss reservation sweep
