.nervk cursed v7 — progression pass
====================================

Run:
  chmod +x ./nervk
  ./nervk

or:
  ./RUN_ME.sh

Rebuild:
  ./REBUILD_ME.sh

Controls:
  WASD       move
  Mouse      look
  LMB        fire / start / restart
  1/2/3      pistol / shotgun / rocket
  Mousewheel cycle weapons
  M          toggle automap
  TAB        hold automap
  ESC        quit

What changed in v7:
  - permadeath death readout: final depth + original seed printed to terminal
  - death screen shows depth, seed, and in-process best depth
  - perk tier every 5 floors: extra supplies between descents + curse resistance
  - boss breach floor every 6 floors: big brute, multiple spitters, stalker pressure
  - rare temporary pickups:
      SPEED = faster movement for a short burst
      RAGE  = stronger shots / rocket blasts for a short burst
  - still no asset files; SDL/GL/libm are loaded at runtime; DT_NEEDED is libc only

Seed sharing:
  ./nervk --seed 12345

On death, terminal output looks like:
  [nervk] died depth=17 seed=00C0FFEE best=17

Tiny build notes:
  build_goblin.sh uses the bundled compat headers by default and autotunes xz.
  Set USE_SYSTEM_HEADERS=1 if you want distro SDL2/GL headers instead.
