#!/bin/sh
set -eu
SRC=${SRC:-nervk.c}
RAW=${RAW:-nervk_raw.raw}
SST=${SST:-nervk_raw.sstrip}
OUT=${OUT:-nervk}
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
CFLAGS="-Oz -Wall -flto -fwhole-program -fno-plt -no-pie -fno-toplevel-reorder -fno-reorder-functions -fno-schedule-insns -fno-schedule-insns2 -fno-ipa-cp -fno-ipa-sra -fno-tree-sra -fno-expensive-optimizations -fno-asynchronous-unwind-tables -fno-unwind-tables -ffunction-sections -fdata-sections -fno-stack-protector -fomit-frame-pointer -fmerge-all-constants -fno-math-errno -fno-ident -fno-lto -fno-inline -fno-jump-tables -fno-code-hoisting -fno-tree-dominator-opts -fno-tree-fre -fno-tree-sink -fno-tree-slsr -fno-tree-forwprop"
LDFLAGS="-fno-lto -flto -no-pie -nostartfiles -Wl,-e,_start -Wl,--gc-sections -Wl,--build-id=none -Wl,-z,norelro -Wl,-z,noseparate-code -Wl,--as-needed -Wl,--hash-style=sysv -fno-lto"
SDL_CFLAGS="-I$HERE/compat"
printf '[build] start:    syscall _start\n'
printf '[build] source:   %s\n' "$SRC"
gcc -c -Os -fno-asynchronous-unwind-tables -fno-unwind-tables -fno-ident start_syscall.S -o start_asm.o
gcc $CFLAGS $SDL_CFLAGS "$SRC" start_asm.o -o "$RAW" $LDFLAGS
strip -s "$RAW"
printf '[build] strip:    %s bytes\n' "$(stat -c%s "$RAW")"
cp "$RAW" "$SST"
if command -v sstrip >/dev/null 2>&1; then sstrip "$SST"; else python3 "$HERE/tiny_tools/sstrip64.py" "$SST"; fi
printf '[build] sstrip:   %s bytes\n' "$(stat -c%s "$SST")"
best=; best_sz=999999999; best_desc=
for lc in 0 1 2 3 4; do
  for pb in 0 1 2; do
    tmp="$SST.lzma.lc${lc}.pb${pb}"
    xz --format=lzma -9e --lzma1=preset=9e,pb=$pb,lc=$lc -c "$SST" > "$tmp"
    sz=$(stat -c%s "$tmp")
    [ "$sz" -lt "$best_sz" ] && best_sz=$sz && best="$tmp" && best_desc="lc=$lc pb=$pb"
  done
done
mv "$best" "$SST.xz"
rm -f "$SST".lzma.lc*.pb* 2>/dev/null || true
printf '[build] lzma best:%s bytes (%s)\n' "$(stat -c%s "$SST.xz")" "$best_desc"
cat > "$OUT" <<'STUB'
#!/bin/sh
t=/tmp/n.$$;tail -n+3 $0|xz -dc>$t;chmod +x $t;$t "$@";r=$?;rm $t;exit $r
STUB
cat "$SST.xz" >> "$OUT"
chmod +x "$OUT"
sz=$(stat -c%s "$OUT")
printf '[build] runner:   %s bytes\n' "$sz"
if [ "$sz" -lt 32768 ]; then printf '[build] budget:   UNDER 32 KiB (%s bytes headroom)\n' "$((32768-sz))"; else printf '[build] budget:   OVER 32 KiB by %s bytes\n' "$((sz-32768))"; fi
printf '[build] DT_NEEDED:\n'
readelf -d "$RAW" | grep NEEDED || true
