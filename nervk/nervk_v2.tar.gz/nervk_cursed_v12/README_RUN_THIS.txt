# nervk cursed v11 — Black Signal music pass

A sub-32KB native Linux procedural survival FPS.

No assets. No runtime downloads. SDL/OpenGL/libm are loaded at runtime; the
self-extracting runner has only libc as a direct dynamic dependency.

v11 adds a tiny generated fake-tracker soundtrack, **BLACK SIGNAL**. It is not a
WAV/MOD/XM file and does not ship samples. The music is synthesized in the
existing audio callback from a few compact note patterns, pulse/triangle voices,
noise drums, a hook/drop structure, and a stalker warning layer.

## Run

```sh
chmod +x ./nervk
./nervk
```

Or:

```sh
./RUN_ME.sh
```

## Seed sharing

```sh
./nervk --seed 0xC0FFEE
```

Title screen:

```text
E             edit seed
0-9 A-F       type hex seed
BACKSPACE     delete seed digit
ENTER         apply seed
CLICK         start run
```

Death screen:

```text
C             copy seed command
R             replay current floor
CLICK         restart run from floor 1
```

## Controls

```text
WASD          move
Mouse         look
LMB           fire
1             pistol
2             shotgun
3             rocket launcher
Mouse wheel   cycle weapon
M             toggle automap
TAB           hold automap
ESC           quit
```

## Build

```sh
./REBUILD_ME.sh
```

Measured here:

```text
runner:    32093 bytes
budget:    UNDER 32 KiB
DT_NEEDED: libc.so.6 only
smoke:     OK
```

This is toolchain-sensitive. v9 had about 1307 bytes headroom here; v11 has only
about 595 bytes here, so more features need a shrink pass first.
