nervk v20 HAIL MARY text-fix build

Run:
  chmod +x ./nervk
  ./nervk

Seed/floor:
  ./nervk --seed 0xDEADBEEF --floor 18

Title screen:
  E edits seed
  F edits floor
  ENTER applies edit
  CLICK starts

Death screen:
  C copies run+floor command
  R replays current floor
  CLICK restarts from floor 1

Notes:
  This keeps the v19 shrink work but restores the missing UI text/cursor.
  It is still a gameplay build, not a diagnostic build. Use v18 for --smoke/log capture.


v31 note: without --seed, each launch generates a fresh random run seed. Use --seed to reproduce a run.
