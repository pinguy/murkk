nervk cursed v16
=================

v16 adds title-screen floor entry for shared run+floor challenges.

Run:
  chmod +x ./nervk
  ./nervk

Command-line seed/floor:
  ./nervk --seed 0xDEADBEEF --floor 18

Title screen:
  E          edit seed
  F          edit floor
  0-9 A-F    seed hex digits while editing seed
  0-9        floor digits while editing floor
  BACKSPACE  delete
  ENTER      apply edit
  CLICK      start run

Death screen:
  C          copy ./nervk --seed 0xXXXXXXXX --floor N
  R          replay current floor from stored floor-start state
  CLICK      restart whole run from floor 1

Build:
  ./REBUILD_ME.sh
