NERVK CURSED DESCENT v6
=======================

Run prebuilt:
  ./RUN_ME.sh
  # or directly:
  chmod +x ./nervk
  ./nervk

Rebuild:
  ./REBUILD_ME.sh
  # or: sh ./build_goblin.sh

Controls:
  WASD          move
  Mouse         look
  LMB           fire
  Mouse wheel   change weapon
  1/2/3         pistol / shotgun / rocket
  M             toggle automap
  TAB           hold automap
  ESC           quit

What changed in v6:
- Added a floor 8+ random STALKER event.
- Each floor after 7 has a rising-but-capped chance to be stalked.
- Even on stalked floors, the arrival timer is random.
- The stalker gives a warning pulse, appears, hunts briefly, then vanishes.
- While active it can blink/teleport elsewhere on the map and keep hunting.
- It cannot be killed.
- Shooting it freezes it for a short time; rockets freeze it longer.
- It does moderate chip damage, so the threat is death by repeated visits,
  not cheap instant death.
- The automap shows the stalker while it is present.

Important:
- .patch files are diffs. Do not run them with bash.
- To apply a patch manually: patch -p0 < nervk_cursed_v6_stalker.patch
- The build script defaults to bundled tiny SDL/GL compat headers because
  distro headers can produce a larger binary.
- To force system headers: USE_SYSTEM_HEADERS=1 ./build_goblin.sh
- The build script autotunes xz settings and keeps the smallest stream.

Expected result varies slightly by GCC/binutils/xz version, but should be
around 30 KB and only list libc.so.6 under DT_NEEDED.
